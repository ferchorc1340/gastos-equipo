# Gastos del Equipo — Guía de despliegue

App para registrar y dividir gastos entre Cami, Ale, Kathy y Fernando.

---

## Lo que necesitás crear (todo gratis)

| Servicio | Para qué | Link |
|----------|----------|------|
| GitHub | Guardar el código | github.com |
| Supabase | Base de datos compartida | supabase.com |
| Vercel | Hosting del link final | vercel.com |

---

## Paso 1 — Supabase (base de datos)

1. Entrá a **supabase.com** → New project
2. Dale un nombre: `gastos-equipo`, elige una región (US East está bien)
3. Anotá la contraseña que genera — la vas a necesitar
4. Cuando cargue el proyecto, andá a **SQL Editor** (ícono de código en el menú izquierdo)
5. Copiá todo el contenido del archivo `supabase-schema.sql` y ejecutalo con el botón Run
6. Ahora andá a **Project Settings → API**
7. Copiá estos dos valores:
   - **Project URL** → esto es tu `SUPABASE_URL`
   - **anon / public key** → esto es tu `SUPABASE_ANON_KEY`

---

## Paso 2 — API Key de Anthropic (para leer facturas)

1. Entrá a **console.anthropic.com**
2. API Keys → Create Key
3. Copiá la key → esto es tu `ANTHROPIC_KEY`

> Nota: esta key se usa solo para leer la razón social de las facturas.
> Si preferís no usarla, el campo Comercio sigue funcionando de forma manual.

---

## Paso 3 — Configurar el archivo app.js

Abrí el archivo `app.js` y reemplazá las tres líneas al inicio:

```js
const SUPABASE_URL    = 'TU_SUPABASE_URL';       // pega tu Project URL
const SUPABASE_ANON_KEY = 'TU_SUPABASE_ANON_KEY'; // pega tu anon key
const ANTHROPIC_KEY   = 'TU_ANTHROPIC_API_KEY';  // pega tu API key
```

---

## Paso 4 — Subir a GitHub

1. Entrá a **github.com** → New repository
2. Nombre: `gastos-equipo`, público o privado (ambos funcionan con Vercel)
3. Subí los archivos: `index.html`, `style.css`, `app.js`
   - Podés arrastrarlos directo en la interfaz web de GitHub
   - O usar Git desde la terminal:
     ```bash
     git init
     git add .
     git commit -m "primera versión"
     git branch -M main
     git remote add origin https://github.com/TU_USUARIO/gastos-equipo.git
     git push -u origin main
     ```

---

## Paso 5 — Desplegar en Vercel

1. Entrá a **vercel.com** → Add New Project
2. Conectá tu cuenta de GitHub si no la tenés conectada
3. Importá el repositorio `gastos-equipo`
4. Dejá todo por defecto → Deploy
5. En 30 segundos tenés tu link: `gastos-equipo.vercel.app` (o similar)

---

## Paso 6 — Compartir con el equipo

Mandá el link a Cami, Ale, Kathy y Fernando.
Cada quien lo abre desde el celular, agrega al pantalla de inicio como acceso directo:

**iPhone:** Safari → botón compartir → "Agregar a pantalla de inicio"
**Android:** Chrome → menú (tres puntos) → "Agregar a pantalla de inicio"

Funciona como una app sin instalación.

---

## Actualizaciones futuras

Si querés cambiar algo en la app (agregar miembros, cambiar diseño, etc.):
- Editá el archivo correspondiente
- Subí el cambio a GitHub
- Vercel lo despliega automáticamente en segundos

---

## Archivos del proyecto

```
gastos-equipo/
├── index.html          — estructura de la app
├── style.css           — estilos y diseño
├── app.js              — lógica y conexión a Supabase
└── supabase-schema.sql — schema de base de datos (ejecutar una sola vez)
```
